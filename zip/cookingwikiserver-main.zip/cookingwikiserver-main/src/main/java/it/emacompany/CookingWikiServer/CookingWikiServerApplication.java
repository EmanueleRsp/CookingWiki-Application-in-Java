package it.emacompany.CookingWikiServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookingWikiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookingWikiServerApplication.class, args);
	}

}
