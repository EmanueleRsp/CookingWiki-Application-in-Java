package it.emacompany.cookingwiki;

public enum SearchType {
    LAST_RECIPE,
    TAGS,
    NAME,
    SELF,
    PREF
}
